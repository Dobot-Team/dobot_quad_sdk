"""
DDS Middleware Python Bindings

基于 CycloneDDS-CXX 的 DDS 中间件 Python 绑定库
"""

import os
import sys

# 导入编译好的模块
try:
    # 尝试导入 .so 文件
    from .dds_middleware_python import *
except ImportError:
    # 如果失败，尝试直接导入（兼容旧的导入方式）
    import dds_middleware_python
    # 将所有内容导入到当前命名空间
    globals().update({k: v for k, v in dds_middleware_python.__dict__.items() 
                      if not k.startswith('_')})

__version__ = "0.1.0"
__all__ = [name for name in dir() if not name.startswith('_')]
